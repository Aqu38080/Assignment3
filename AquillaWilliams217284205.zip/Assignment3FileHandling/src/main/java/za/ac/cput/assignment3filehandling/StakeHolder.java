/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.Serializable;


public class StakeHolder implements Serializable{
    
    private String stHolderId;

    public StakeHolder() {
    }
    
    public StakeHolder(String stHolderId) {
        this.stHolderId = stHolderId;
    }
    
    public String getStHolderId() {
        return stHolderId;
    }

    public void setStHolderId(String stHolderId) {
        this.stHolderId = stHolderId;
    }

    @Override
    public String toString() {
       return stHolderId;
    }

}
    

