/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class WritingSupplierClassSer {
    
    private ObjectOutputStream output;
    Supplier[] supplierArray = new Supplier[5];
    
    public void populateArray(){
        
        supplierArray[0] = new Supplier("S270", "Grand Theft Auto", "Toyota", "Mid-size sedan");
        supplierArray[1] = new Supplier("S400", "Prime Motors", "Lexus", "Luxury sedan");
        supplierArray[2]=new Supplier("S300", "We got Cars", "Toyota", "10-seater minibus");
           supplierArray[3] = new Supplier("S350", "Auto Delight", "BMW", "Luxury SUV");
          supplierArray[4] = new Supplier("S290", "MotorMania", "Hyundai", "compact budget");
    
}
    public void openFile(){
        try{
            output = new ObjectOutputStream( new FileOutputStream( "stakeholder.ser" ) ); 
            System.out.println("*** ser file created and opened for writing ***");               
        }
        catch (IOException ioe){
            System.out.println("error opening ser file: " + ioe.getMessage());
            System.exit(1);
        }
    }
    public void closeFile(){
        try{
        output.close( ); 
        }
        catch (IOException ioe){            
            System.out.println("error closing ser file: " + ioe.getMessage());
            System.exit(1);
        }        
    }        

public void writeToFile(){
    try{
        for(int i =0; i<supplierArray.length; i++){
        output.writeObject(supplierArray[i]);
        System.out.printf("object %d write ser file: \n",i);
    }
    }
       catch(IOException ioe){
             System.out.println("****error writing ser file" + ioe);
             
         }
         finally{
             closeFile();
             System.out.println("** file ser have closed");
         }
     }
    public static void main(String[] args) throws IOException {
       WritingSupplierClassSer obj = new WritingSupplierClassSer();
       obj.populateArray();
       obj.openFile();
       obj.writeToFile();
       obj.closeFile();
    }           
}
