/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class ReadingSupplierClassSer {
    
    private ObjectInputStream input;
    Supplier suppplier;
    Supplier[] supplierArray = new Supplier[5];
    
    public void openFile(){
        
        try{
            input = new ObjectInputStream(new FileInputStream("stakeholder.ser"));
            System.out.println("****ser file opened for reading");
            
        }
        catch(IOException ioe){
            System.out.println("***error opening ser file"+ ioe.getMessage());
            
        }
    }
     public void closeFile(){
         try{
             
             input.close();
             
         }
         catch(IOException ioe){
             System.out.println("***error closing ser file"+ ioe.getMessage());
             
         }
     }  
    
    
     public void readfromFile(){
         try{
             
             for(int i = 0;i<supplierArray.length; i++){
                 supplierArray[i] = (Supplier)input.readObject();
                 System.out.println(supplierArray[i]);
             }
         }
             catch(ClassNotFoundException ioe){
                     System.out.println("**error reading ser file" + ioe);
                     
                     }
         
         catch(IOException ioe){
             System.out.println("****error reading ser file" + ioe);
             
         }
         finally{
             closeFile();
             System.out.println("** file ser have closed");
         }
     }
      public static void main(String[] args) throws IOException {
    ReadingSupplierClassSer obj = new ReadingSupplierClassSer();
       
       obj.openFile();
       obj.readfromFile();
       obj.closeFile();
}
}