/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;


public class SupplierWorkerClass {
    
    ObjectInputStream obj;
    ArrayList<Supplier> suppliers;
    ArrayList<Customer> customers;
    
    public SupplierWorkerClass (){
        suppliers = new ArrayList();
    }
  
    public void ValuesList() throws FileNotFoundException, IOException {
        try{
            obj = new ObjectInputStream(new FileInputStream("stakeholder.ser"));
            while(true){
                suppliers.add((Supplier)obj.readObject());
            } 
        }
        catch(EOFException e){
           System.out.println("File closed.");
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
          catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
          }
        SupplierToTextFile();
    }
    
    public void displaySuppliers(){
        for(Supplier s: suppliers){
            System.out.println(s);
        }
    }
    
    public void SupplierToTextFile(){
        try{
    PrintWriter writer = new PrintWriter(new FileWriter("supplierOutFile.txt"));
    System.out.println("==================== SUPPLIERS ====================\n");
    System.out.println("ID   	Name      Prod Type	Description    \n");
    System.out.println("===================================================\n");
        for(int i = 0; i < suppliers.size() - 1; i++){
            for(int s = i + 1; s < suppliers.size(); s++){
                if(suppliers.get(i).getName().compareTo(customers.get(s).getFirstName()) > 0){
                   Supplier sup = suppliers.get(i);
                   suppliers.set(i, suppliers.get(s)); 
                   suppliers.set(s, sup);
            }
        }
    }
            for(Supplier s: suppliers){
                if( s.getName().length() < 8)
                    System.out.println(s.getStHolderId()+ "\t"+ s.getName()+ "\t\t\t" +s.getProductType()+ "\t\t\t" + s.getProductDescription()+"\n");
                else
                    System.out.println(s.getStHolderId()+ "\t"+ s.getName()+ "\t\t" + s.getProductType()+ "\t\t" + s.getProductDescription()+"\n");
            }
            writer.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public static void main(String[] args) throws IOException {
    new SupplierWorkerClass().ValuesList();
    }  
}

