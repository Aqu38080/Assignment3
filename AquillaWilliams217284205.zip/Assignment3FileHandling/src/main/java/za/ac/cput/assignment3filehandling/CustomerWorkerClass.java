/**
 * ADP2 Assignment3: File Handling
 * Aquilla Williams
 * 217284205 
 * Due Date: 09/06/2021 8mp
 */
package za.ac.cput.assignment3filehandling;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;


public class CustomerWorkerClass {
    
    ObjectInputStream obj;
    ArrayList<Customer> customers;
    ArrayList<Integer> age;
    int c = 0;
    
    public CustomerWorkerClass(){
        customers = new ArrayList();
        age = new ArrayList();
    }
  
    public void ValuesList() throws FileNotFoundException, IOException {
        try{
            obj = new ObjectInputStream(new FileInputStream("stakeholder.ser"));
            while(true){
                customers.add((Customer)obj.readObject());
            } 
        }
        catch(EOFException e){
           System.out.println("File closed.");
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
          catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println("unSorted customers");
        showCustomers();
        sortCustomers();
        System.out.println("Sort customers");
        showCustomers();
        System.out.println("Ages of customers");
        ages();
        System.out.println("Dates Changed");
        dateToChange();
        showCustomers();
        writeCustomerToTextFile();
    }
    
    public void showCustomers(){
        for(Customer c: customers){
            System.out.println(c);
        }
    }
    
    public void sortCustomers(){
        for(int i = 0; i < customers.size() - 1; i++){
            for(int c = i + 1; c < customers.size(); c++){
                if(customers.get(i).getStHolderId().compareTo(customers.get(c).getStHolderId()) > 0){
                    Customer cus = customers.get(i);
                    customers.set(i, customers.get(c)); 
                    customers.set(c, cus);
                }
            }
        }
    }
    
    public void ages(){
        for(Customer c: customers){
           String []birth = c.getDateOfBirth().split("-");
           int born = Integer.parseInt(birth[0]);
            System.out.println(c.getSurName()+" > "+(2021-born));
            age.add((2021-born));
        }
    }
    
    public void dateToChange(){
        for(Customer c: customers){
            String []month = c.getDateOfBirth().split("-");
            String born = month[1];
            if(born.equals("01"))
                c.setDateOfBirth(month[2]+" Jan "+month[0]);
            else if(born.equals("02"))
                c.setDateOfBirth(month[2]+" Feb "+month[0]);
             else if(born.equals("03"))
                c.setDateOfBirth(month[2]+" Mar "+month[0]);
             else if(born.equals("04"))
                c.setDateOfBirth(month[2]+" Apr "+month[0]);
             else if(born.equals("05"))
                c.setDateOfBirth(month[2]+" May "+month[0]);
             else if(born.equals("06"))
                c.setDateOfBirth(month[2]+" Jun "+month[0]);
             else if(born.equals("07"))
                c.setDateOfBirth(month[2]+" Jul "+month[0]);
             else if(born.equals("08"))
                c.setDateOfBirth(month[2]+" Aug "+month[0]);
             else if(born.equals("09"))
                c.setDateOfBirth(month[2]+" Sep "+month[0]);
             else if(born.equals("10"))
                c.setDateOfBirth(month[2]+" Oct "+month[0]);
             else if(born.equals("11"))
                c.setDateOfBirth(month[2]+" Nov "+month[0]);
             else if(born.equals("12"))
                c.setDateOfBirth(month[2]+" Dec "+month[0]);
             else 
                c.setDateOfBirth(month[2]+" Invalid "+month[0]);
        }
    }
    
    public void writeCustomerToTextFile() throws IOException{
        PrintWriter writer = new PrintWriter(new FileWriter("customerOutFile.txt"));
        System.out.println("============================= CUSTOMERS =================================\n");
        System.out.println("ID      Name        Surname         Date of birth       Age  \n");
        System.out.println("=========================================================================\n");
        int i = 0;
        int rent = 0;
        for(Customer c: customers){
            if( c.getSurName().length() < 8)
                System.out.println(c.getStHolderId()+ "\t"+ c.getFirstName()+ "\t\t" + c.getSurName()+ "\t\t" + c.getDateOfBirth()+ "\t\t" + age.get(i)+"\n");
            else
                System.out.println(c.getStHolderId()+ "\t"+ c.getFirstName()+ "\t\t" + c.getSurName()+ "\t" + c.getDateOfBirth()+ "\t\t" + age.get(i)+"\n");
            i++;
            if(c.getCanRent())
                rent++;
        }
        System.out.println("Number of customers who can rent: "+rent+"\n");
        System.out.println("Number of customers who cannot rent: "+(customers.size()-rent)+"\n");
        writer.close();
    }
    
    public static void main(String[] args) throws IOException {
        new CustomerWorkerClass().ValuesList();
    }           
}




